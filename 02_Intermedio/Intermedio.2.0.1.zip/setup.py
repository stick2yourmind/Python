from distutils.core import setup
setup(
name = 'Unidad 06 - Python nivel intermedio',
version = '1.1',
py_modules = ['App'],
author = 'Jonathan Max Saravia Moreira',
author_email = 'saravia.jonathan@gmail.com',
url = '---',
description = 'Unidad 06 - Python nivel intermedio: aplicación MVC',
packages=['src'],
)
