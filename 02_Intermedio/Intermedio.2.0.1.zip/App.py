from view.view_main import *

if __name__ == '__main__':
    a = WindowView(tab="default")
    mainloop()